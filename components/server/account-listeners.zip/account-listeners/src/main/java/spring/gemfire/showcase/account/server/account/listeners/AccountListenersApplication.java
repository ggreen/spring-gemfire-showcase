package spring.gemfire.showcase.account.server.account.listeners;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountListenersApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountListenersApplication.class, args);
	}

}
