package spring.gemfire.showcase.account.server.account.listeners;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountListenersApplicationTests {

	@Test
	void contextLoads() {
	}

}
